#include "StdAfx.h"
#include ".\simulationsparams.h"


CSimulationsParams::~CSimulationsParams(void)
{
}
